tp @e[tag=kino.actor] ~ 330 ~
kill @e[tag=kino]
scoreboard players set #playing kino.t 0
