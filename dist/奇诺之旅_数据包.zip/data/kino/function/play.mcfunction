function kino:scene/0
