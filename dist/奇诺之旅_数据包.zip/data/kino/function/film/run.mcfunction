$function kino:film/t/$(f)
