title @a actionbar {"text": "", "extra": [{"text": "奇诺：", "color": "#f2d27a"}, {"text": "最初说谎骗人的是你们，这算是违反契约的行为。", "color": "#FFFFFF"}]}
