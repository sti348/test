playsound minecraft:block.pointed_dripstone.drip_water ambient @a -75 67.5 -135.9 0.7 0.894
