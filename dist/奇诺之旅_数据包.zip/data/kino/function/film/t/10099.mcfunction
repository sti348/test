title @a actionbar {"text": "", "extra": [{"text": "奇诺：", "color": "#f2d27a"}, {"text": "所以我要回去艾鲁梅斯那里了，接下来你们自己看着办吧。", "color": "#FFFFFF"}]}
