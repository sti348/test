title @a actionbar {"text": "", "extra": [{"text": "奇诺：", "color": "#f2d27a"}, {"text": "我会把事情跟那些人坦白说清楚，请他们放过我跟艾鲁梅斯。", "color": "#FFFFFF"}]}
