spectate @e[tag=kino.cam,limit=1] @a
tp @e[tag=kino.cam,limit=1] 0 120 0 10 -30
playsound kino:sfx.birds ambient @a -1.3 75.142 7.1 0.9 1.049
item replace entity @a armor.head with minecraft:paper[minecraft:equippable={slot:"head",camera_overlay:"kino:misc/black"}]
time set 1000
