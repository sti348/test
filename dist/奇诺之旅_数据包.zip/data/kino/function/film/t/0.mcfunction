spectate @e[tag=kino.cam,limit=1] @a
tp @e[tag=kino.cam,limit=1] 0 120 0 10 -30
item replace entity @a armor.head with minecraft:paper[minecraft:equippable={slot:"head",camera_overlay:"kino:misc/black"}]
time set 1000
