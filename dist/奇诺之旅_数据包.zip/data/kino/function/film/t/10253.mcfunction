title @a actionbar {"text": "", "extra": [{"text": "奇诺：", "color": "#f2d27a"}, {"text": "奇怪了……我越想越觉得奇怪，那个时候怎么没发现到呢？", "color": "#FFFFFF"}]}
