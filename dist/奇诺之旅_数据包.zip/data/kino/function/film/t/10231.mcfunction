playsound minecraft:block.pointed_dripstone.drip_water ambient @a -77.4 67.5 -133.2 0.7 1.237
