title @a actionbar {"text": "", "extra": [{"text": "奇诺：", "color": "#f2d27a"}, {"text": "我明白了。既然你们不回答就算了，但是现在我已经没必要履行保护你们不受山贼伤害的约定，", "color": "#FFFFFF"}]}
