title @a actionbar {"text": "", "extra": [{"text": "奇诺：", "color": "#f2d27a"}, {"text": "要是不尽快把对方全部歼灭，最后吃败仗的会是我们。", "color": "#FFFFFF"}]}
