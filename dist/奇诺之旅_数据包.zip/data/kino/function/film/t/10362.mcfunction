playsound minecraft:block.pointed_dripstone.drip_water ambient @a -75.4 67.5 -133 0.7 0.96
