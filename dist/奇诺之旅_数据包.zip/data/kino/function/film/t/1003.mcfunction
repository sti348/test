title @a actionbar {"text": "", "extra": [{"text": "胡须男：", "color": "#e0b080"}, {"text": "不会花费你太多时间的，可以吗？", "color": "#FFFFFF"}]}
