title @a actionbar {"text": "", "extra": [{"text": "奇诺：", "color": "#f2d27a"}, {"text": "咦？『全部歼灭』……奇怪了……", "color": "#FFFFFF"}]}
