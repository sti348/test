title @a actionbar {"text": "", "extra": [{"text": "男子：", "color": "#d8d8d8"}, {"text": "什么？你想背叛我们吗？", "color": "#FFFFFF"}]}
