title @a actionbar {"text": "", "extra": [{"text": "医生：", "color": "#bfe3c0"}, {"text": "什么事啊？", "color": "#FFFFFF"}]}
