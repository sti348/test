playsound kino:sfx.birds ambient @a 49.8 74.023 -10.5 0.9 1.033
