tp @e[type=minecraft:mannequin,tag=kino.a.kino,limit=1] -73.8 64.5 -133.6 90 34.607
time set 5000
