title @a actionbar {"text": "", "extra": [{"text": "奇诺：", "color": "#f2d27a"}, {"text": "既然你们不把知道的事情告诉我，那我也无可奈何——", "color": "#FFFFFF"}]}
