execute as @a at @s run playsound kino:voice.c44166a2ab voice @s ~ ~ ~ 1 1
title @a actionbar {"text": "", "extra": [{"text": "奇诺：", "color": "#f2d27a"}, {"text": "咦？『全部歼灭』……奇怪了……", "color": "#FFFFFF"}]}
