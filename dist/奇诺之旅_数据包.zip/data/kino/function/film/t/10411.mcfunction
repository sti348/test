title @a actionbar {"text": "", "extra": [{"text": "奇诺：", "color": "#f2d27a"}, {"text": "就是那群山贼的行动。当他们挡住去路，把我们逼到旁边的小路时，怎么没在那里设下陷阱呢？", "color": "#FFFFFF"}]}
