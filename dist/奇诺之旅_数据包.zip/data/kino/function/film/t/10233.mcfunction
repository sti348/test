spectate @e[tag=kino.cam,limit=1] @a
tp @e[tag=kino.cam,limit=1] -75.793 66.1 -133.764 -85.305 1.432
