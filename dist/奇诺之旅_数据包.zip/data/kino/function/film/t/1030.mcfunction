spectate @e[tag=kino.cam,limit=1] @a
tp @e[tag=kino.cam,limit=1] 44.78 66.63 -0.095 -125 1.364
