playsound minecraft:block.pointed_dripstone.drip_water ambient @a -76.1 67.5 -135.5 0.7 1.12
time set 5000
