data merge entity @e[tag=kino.cam,limit=1] {teleport_duration:2}
