execute as @a at @s run playsound kino:voice.092be472d3 voice @s ~ ~ ~ 1 1
title @a actionbar {"text": "", "extra": [{"text": "男子：", "color": "#d8d8d8"}, {"text": "怎、怎么了吗？", "color": "#FFFFFF"}]}
