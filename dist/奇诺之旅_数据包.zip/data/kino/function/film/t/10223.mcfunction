tp @e[type=minecraft:mannequin,tag=kino.a.kino,limit=1] -73.8 64.5 -133.6 90 23.926
execute as @a at @s run playsound kino:voice.56dd6e5fc0 voice @s ~ ~ ~ 1 1
title @a actionbar {"text": "", "extra": [{"text": "奇诺：", "color": "#f2d27a"}, {"text": "奇怪了……我越想越觉得奇怪，那个时候怎么没发现到呢？", "color": "#FFFFFF"}]}
