spectate @e[tag=kino.cam,limit=1] @a
tp @e[tag=kino.cam,limit=1] -75.23 66.1 -133.653 100 1.432
