spectate @e[tag=kino.cam,limit=1] @a
tp @e[tag=kino.cam,limit=1] -76.9 66.1 -135 -61.113 1.729
time set 5000
