data merge entity @e[tag=kino.cam,limit=1] {teleport_duration:2}
tp @e[type=minecraft:mannequin,tag=kino.a.kino,limit=1] -73.8 64.5 -133.6 90 33.496
