title @a actionbar {"text": "", "extra": [{"text": "男子：", "color": "#d8d8d8"}, {"text": "怎、怎么了吗？", "color": "#FFFFFF"}]}
