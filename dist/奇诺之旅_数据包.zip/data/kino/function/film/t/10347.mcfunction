execute as @a at @s run playsound kino:voice.470b6be0c5 voice @s ~ ~ ~ 1 1
title @a actionbar {"text": "", "extra": [{"text": "医生：", "color": "#bfe3c0"}, {"text": "什么事啊？", "color": "#FFFFFF"}]}
