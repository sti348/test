tp @e[type=minecraft:mannequin,tag=kino.a.kino,limit=1] -73.8 64.5 -133.6 90 14.236
playsound minecraft:block.pointed_dripstone.drip_water ambient @a -77.1 67.5 -134 0.7 1.297
