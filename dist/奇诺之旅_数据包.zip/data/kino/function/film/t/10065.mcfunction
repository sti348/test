spectate @e[tag=kino.cam,limit=1] @a
tp @e[tag=kino.cam,limit=1] -75.539 66.15 -134.066 -75 3.18
