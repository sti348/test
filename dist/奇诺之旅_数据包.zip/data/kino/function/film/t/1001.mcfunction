title @a actionbar {"text": "", "extra": [{"text": "胡须男：", "color": "#e0b080"}, {"text": "嗨，你是旅行者吧？抱歉中途把你拦了下来，我们有点事情想请教。", "color": "#FFFFFF"}]}
