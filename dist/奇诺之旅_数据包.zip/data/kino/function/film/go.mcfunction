spectate @e[tag=kino.cam,limit=1] @a
scoreboard players set #playing kino.t 1
