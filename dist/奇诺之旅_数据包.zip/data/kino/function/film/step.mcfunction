kill @e[tag=kino.gone]
scoreboard players add #f kino.t 1
execute store result storage kino:film f int 1 run scoreboard players get #f kino.t
function kino:film/run with storage kino:film
execute if score #f kino.t matches 39349.. run function kino:stop
