tellraw @a {"text":"[奇诺之旅] 开始搭建场景（约需一分钟，请保持在世界中）…","color":"gold"}
gamemode spectator @a
difficulty peaceful
weather clear 1000000
function kino:rules/legacy
function kino:rules/modern
forceload add -162 -192 -3 -33
forceload add -162 -32 -3 50
forceload add -2 -192 157 -33
forceload add -2 -32 157 50
forceload add 158 -192 310 -33
forceload add 158 -32 310 50
tp @a -80 90 -100
schedule function kino:build/clear 100t
