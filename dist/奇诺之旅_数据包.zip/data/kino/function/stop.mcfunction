scoreboard players set #playing kino.t 0
stopsound @a
item replace entity @a armor.head with minecraft:air
title @a actionbar ""
tellraw @a {"text":"[奇诺之旅] 放映结束。/function kino:play 重新播放","color":"gold"}
