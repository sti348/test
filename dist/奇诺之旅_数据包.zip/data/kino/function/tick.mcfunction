execute if score #playing kino.t matches 1 run function kino:film/step
