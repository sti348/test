scoreboard objectives add kino.t dummy
tellraw @a [{"text":"[奇诺之旅] ","color":"gold"},{"text":"已加载。先运行 ","color":"gray"},{"text":"/function kino:setup","color":"yellow"},{"text":" 搭建场景，再运行 ","color":"gray"},{"text":"/function kino:play","color":"yellow"}]
