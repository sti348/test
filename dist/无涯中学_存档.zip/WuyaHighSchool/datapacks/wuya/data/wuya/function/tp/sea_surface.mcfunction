execute in minecraft:overworld run tp @s 4150.5 -60 -141.5 0 10
