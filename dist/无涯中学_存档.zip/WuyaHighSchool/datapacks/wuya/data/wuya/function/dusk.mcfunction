time set 12700
