execute in minecraft:overworld run tp @s 2420.5 -55 930.5 180 -10
