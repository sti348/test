execute in minecraft:the_nether run tp @s -219.5 64 37.5 90 -15
