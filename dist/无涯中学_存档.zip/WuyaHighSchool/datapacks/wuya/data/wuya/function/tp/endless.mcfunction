execute in minecraft:overworld run tp @s 40.5 -60 -823.5 230 -16
