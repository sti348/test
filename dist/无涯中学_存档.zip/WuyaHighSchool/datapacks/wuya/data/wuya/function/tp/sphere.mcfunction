execute in minecraft:overworld run tp @s 4170.5 -761 -109.5 200 -25
