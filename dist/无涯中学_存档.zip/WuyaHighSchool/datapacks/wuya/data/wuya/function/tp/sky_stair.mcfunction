execute in minecraft:overworld run tp @s -519.5 -60 -2429.5 180 -40
