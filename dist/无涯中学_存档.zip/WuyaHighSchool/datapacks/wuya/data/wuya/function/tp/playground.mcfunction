execute in minecraft:overworld run tp @s 672.5 -38 -39.5 0 5
