execute in minecraft:overworld run tp @s -481.5 -60 658.5 0 -18
