execute in minecraft:overworld run tp @s 3960.5 -761 -703.5 180 -15
