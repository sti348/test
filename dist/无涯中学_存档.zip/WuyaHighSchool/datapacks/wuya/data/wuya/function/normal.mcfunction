function #wuya:normal
