execute in minecraft:overworld run tp @s 300.5 -19 498.5 90 0
