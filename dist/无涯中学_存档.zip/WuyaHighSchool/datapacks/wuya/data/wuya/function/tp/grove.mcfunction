execute in minecraft:overworld run tp @s -1213.5 -60 -495.5 328 -5
