execute in minecraft:overworld run tp @s 3120.5 -60 -2149.5 160 -10
