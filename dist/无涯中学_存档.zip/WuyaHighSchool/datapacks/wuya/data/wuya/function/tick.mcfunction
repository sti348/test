execute as @a[tag=!wuya_seen] at @s run function wuya:welcome
