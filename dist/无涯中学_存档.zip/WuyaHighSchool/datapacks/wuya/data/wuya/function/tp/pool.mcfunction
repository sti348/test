execute in minecraft:overworld run tp @s 192.5 -50 742.5 180 14
