execute in minecraft:overworld run tp @s -153.5 -59 692.5 125 -6
