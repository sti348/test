execute in minecraft:overworld run tp @s -399.5 1041 -3224.5 180 -8
