execute in minecraft:overworld run tp @s 2850.5 -54 -89.5 180 -10
