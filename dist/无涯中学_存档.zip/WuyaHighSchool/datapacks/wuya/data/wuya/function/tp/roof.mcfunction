execute in minecraft:overworld run tp @s 260.5 174 505.5 180 10
