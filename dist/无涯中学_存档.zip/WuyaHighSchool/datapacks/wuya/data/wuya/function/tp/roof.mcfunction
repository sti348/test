execute in minecraft:overworld run tp @s 260.5 174 470.5 200 6
