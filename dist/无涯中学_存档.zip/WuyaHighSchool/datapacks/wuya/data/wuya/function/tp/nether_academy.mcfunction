execute in minecraft:the_nether run tp @s -57.5 64 -159.5 108 -30
