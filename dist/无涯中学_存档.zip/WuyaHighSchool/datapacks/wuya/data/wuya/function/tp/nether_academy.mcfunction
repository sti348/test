execute in minecraft:the_nether run tp @s -279.5 64 -109.5 180 -20
