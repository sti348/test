execute in minecraft:overworld run tp @s 0.5 -60 1065.5 180 -12
