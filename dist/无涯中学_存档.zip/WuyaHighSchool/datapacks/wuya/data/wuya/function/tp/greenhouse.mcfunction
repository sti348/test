execute in minecraft:overworld run tp @s 481.5 -60 812.5 180 -8
