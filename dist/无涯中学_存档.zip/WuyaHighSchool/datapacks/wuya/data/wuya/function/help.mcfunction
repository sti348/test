tellraw @s {"text":"—— 无涯中学 · 指令 ——","color":"gold"}
tellraw @s {"text":"/function wuya:tp/gate   校门外（出生点）","color":"aqua"}
tellraw @s {"text":"/function wuya:tp/plaza   升旗广场","color":"aqua"}
tellraw @s {"text":"/function wuya:tp/steps   主楼台阶与巨柱","color":"aqua"}
tellraw @s {"text":"/function wuya:tp/canyon   东侧教学楼峡谷","color":"aqua"}
tellraw @s {"text":"/function wuya:tp/corridor   教学楼外廊（崇文楼）","color":"aqua"}
tellraw @s {"text":"/function wuya:tp/clock   钟楼正前方半空","color":"aqua"}
tellraw @s {"text":"/function wuya:tp/roof   主楼屋顶","color":"aqua"}
tellraw @s {"text":"/function wuya:tp/playground   操场看台","color":"aqua"}
tellraw @s {"text":"/function wuya:tp/library   图书馆柱廊","color":"aqua"}
tellraw @s {"text":"/function wuya:tp/endless   无尽长廊楼","color":"aqua"}
tellraw @s {"text":"/function wuya:tp/watertower   巨型水塔","color":"aqua"}
tellraw @s {"text":"/function wuya:tp/lake   校园湖（湖心亭、拱桥）","color":"aqua"}
tellraw @s {"text":"/function wuya:tp/pool   游泳池跳台","color":"aqua"}
tellraw @s {"text":"/function wuya:tp/auditorium   大礼堂","color":"aqua"}
tellraw @s {"text":"/function wuya:tp/greenhouse   植物园温室","color":"aqua"}
tellraw @s {"text":"/function wuya:tp/buses   校车停车场","color":"aqua"}
tellraw @s {"text":"/function wuya:tp/sky   高空俯瞰","color":"aqua"}
tellraw @s {"text":"/function wuya:tiny     缩小成十分之一（1.20.5+），巨物感拉满","color":"light_purple"}
tellraw @s {"text":"/function wuya:normal   恢复正常大小","color":"light_purple"}
tellraw @s {"text":"/function wuya:day | wuya:dusk | wuya:night   切换时间","color":"green"}
