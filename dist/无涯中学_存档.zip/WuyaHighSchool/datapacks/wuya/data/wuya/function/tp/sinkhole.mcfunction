execute in minecraft:overworld run tp @s -2504.5 -60 -449.5 90 35
