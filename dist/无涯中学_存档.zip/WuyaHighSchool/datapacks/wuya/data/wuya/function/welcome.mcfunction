tellraw @s ["",{"text":"—— 无涯中学 ——","color":"gold","bold":true}]
tellraw @s {"text":"暮色版：像暮色森林一样的永恒暮色，教室和路灯都亮着。建议渲染距离 16~32 区块。","color":"gray"}
tellraw @s {"text":"/function wuya:help  查看传送点与玩法","color":"yellow"}
tag @s add wuya_seen
