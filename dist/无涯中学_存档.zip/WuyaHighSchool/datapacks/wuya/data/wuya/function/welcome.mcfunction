tellraw @s ["",{"text":"—— 无涯中学 ——","color":"gold","bold":true}]
tellraw @s {"text":"学海无涯，校园也无涯。建议渲染距离 16~32 区块。","color":"gray"}
tellraw @s {"text":"/function wuya:help  查看传送点与玩法","color":"yellow"}
tag @s add wuya_seen
