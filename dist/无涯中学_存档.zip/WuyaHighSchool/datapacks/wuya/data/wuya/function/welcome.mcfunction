tellraw @s ["",{"text":"—— 无涯中学 ——","color":"gold","bold":true}]
tellraw @s {"text":"黄昏版：太阳刚落，教室和路灯都亮了。建议渲染距离 16~32 区块。","color":"gray"}
tellraw @s {"text":"/function wuya:help  查看传送点与玩法","color":"yellow"}
tag @s add wuya_seen
