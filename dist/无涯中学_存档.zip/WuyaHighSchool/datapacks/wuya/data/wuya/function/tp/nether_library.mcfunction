execute in minecraft:the_nether run tp @s 60.5 64 -149.5 180 -15
