execute in minecraft:overworld run tp @s 874.5 54 686.5 270 0
