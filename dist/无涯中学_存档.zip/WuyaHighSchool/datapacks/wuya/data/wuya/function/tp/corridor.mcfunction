execute in minecraft:overworld run tp @s 642.5 21 686.5 270 0
