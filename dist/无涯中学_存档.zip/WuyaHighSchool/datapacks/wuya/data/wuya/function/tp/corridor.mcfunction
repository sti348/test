execute in minecraft:overworld run tp @s 906.5 54 686.5 270 0
