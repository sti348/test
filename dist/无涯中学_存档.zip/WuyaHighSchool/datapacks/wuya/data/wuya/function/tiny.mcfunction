function #wuya:tiny
tellraw @s {"text":"你变小了。（需要 1.20.5 或更新版本）","color":"light_purple"}
