execute in minecraft:overworld run tp @s 480.5 1361 -3484.5 180 -8
