execute in minecraft:overworld run tp @s 300.5 330 1260.5 192 12
