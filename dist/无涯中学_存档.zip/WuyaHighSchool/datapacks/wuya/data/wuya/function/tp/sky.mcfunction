execute in minecraft:overworld run tp @s 300.5 230 1160.5 192 22
