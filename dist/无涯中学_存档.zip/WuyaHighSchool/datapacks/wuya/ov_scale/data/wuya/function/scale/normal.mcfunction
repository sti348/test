attribute @s minecraft:scale base set 1
