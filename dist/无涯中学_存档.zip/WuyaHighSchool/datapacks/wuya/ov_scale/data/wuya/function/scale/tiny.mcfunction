attribute @s minecraft:scale base set 0.1
